#!/bin/bash

echo "Testing echo hello and exit"
echo hello
echo
echo exit
exit
