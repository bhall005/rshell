#!/bin/bash

echo "Testing echo hello and ls a"
echo hello
echo ls a
echo exit